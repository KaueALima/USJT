insert into carro (id, marca, modelo, ano, valor, tanque, eficiencia) values (22, 'Ford','Fiesta', 2011, 27000, 40, 9);
insert into carro (id, marca, modelo, ano, valor, tanque, eficiencia) values (45, 'Chevrolet','S10', 2016, 67000, 30, 12);
insert into carro (id, marca, modelo, ano, valor, tanque, eficiencia) values (67, 'Volkswagen','Golf', 2018, 98000, 25, 8);
--adicione um usuário
insert into usuario (id, login, senha) values (1, 'admin', 'admin')