package br.kaue.usjt.agenciaveiculos.Agencia.Veiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenciaVeiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgenciaVeiculosApplication.class, args);
	}

}
