package br.kaue.usjt.agenciaveiculos.Agencia.Veiculos.model;

public class Calculadora {
public static double calculaAutonomia (double tanque, double eficiencia) {
	return tanque*eficiencia;
	}
}