package br.kaue.usjt.agenciaveiculos.Agencia.Veiculos.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.kaue.usjt.agenciaveiculos.Agencia.Veiculos.model.Carro;

public interface CarroRepository  extends JpaRepository<Carro, Long>{

}
